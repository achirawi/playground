# Duino-Coin miner for STM32 chips family

- Use platform.io to open/build
- Edit platformio.ini file to setup your upload method
    - I'm uploading my via serial connected to A9/A10 pins    
- Use AVR_Miner as with any other Arduino board
- Tested on:
    - Bluepill (STM32F103) ~6000 H/s
    - Blackpill (STM32F401) ~13700 H/s
    - Blackpill (STM32F411) ~15500 H/s

Happy mining!:)

